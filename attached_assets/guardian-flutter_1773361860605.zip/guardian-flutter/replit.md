# Guardian 3D Flutter Project

## Overview

Guardian 3D Desktop is a Flutter-based application that renders an interactive 3D cube interior viewer. The user can look around inside a colorful 3D cube by moving their mouse or using head tracking via camera + face detection (Google ML Kit).

## Architecture

- **Original target**: Flutter desktop (Windows) with `webview_windows`, `camera`, and `google_ml_kit`
- **Replit environment**: Served as a standalone web app using Node.js + Express
- **Core 3D content**: Three.js WebGL scene embedded in `assets/index.html`

## Key Files

- `lib/main.dart` — Flutter app entry point (Windows desktop app)
- `assets/index.html` — Three.js 3D cube interior scene (the core visual content)
- `server.js` — Express server serving the 3D content on port 5000
- `pubspec.yaml` — Flutter dependencies
- `web/` — Flutter web build target scaffold

## Running in Replit

The app runs via a Node.js Express server that serves `assets/index.html` directly.

- **Workflow**: "Start application" → `node server.js`
- **Port**: 5000
- **URL**: Served at `0.0.0.0:5000`

## Flutter Dependencies

- `webview_windows` — Windows WebView2 wrapper (Windows-only)
- `camera` — Camera access for head tracking
- `google_ml_kit` — Face detection for head tracking
- `permission_handler` — Camera permission management

## Notes

- Flutter SDK is not available in this Replit environment; the Three.js web content is served directly
- The original Flutter app targets Windows desktop with a camera-based head tracking feature
- In the web version, mouse movement controls the 3D cube view
