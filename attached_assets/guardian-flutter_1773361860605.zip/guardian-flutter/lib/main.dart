import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_windows/webview_windows.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:camera/camera.dart';
import 'package:google_ml_kit/google_ml_kit.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Guardian 3D Desktop',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const HeadTrackScreen(),
    );
  }
}

class HeadTrackScreen extends StatefulWidget {
  const HeadTrackScreen({super.key});

  @override
  State<HeadTrackScreen> createState() => _HeadTrackScreenState();
}

class _HeadTrackScreenState extends State<HeadTrackScreen> {
  final _controller = WebviewController();
  double headX = 0.0;
  double headY = 0.0;
  bool _isInitialized = false;
  bool isHeadMode = false;
  bool showPreview = false;
  List<String> _logs = [];
  int frameCount = 0;
  Timer? streamCheckTimer;
  CameraController? _cameraController;
  FaceDetector? _faceDetector;
  List<CameraDescription> _cameras = [];
  CameraDescription? _selectedCamera;

  void _addLog(String message) {
    setState(() {
      _logs.add('${DateTime.now().toString().substring(11,19)} $message');
      if (_logs.length > 30) _logs.removeAt(0);
    });
    print(message);
  }

  @override
  void initState() {
    super.initState();
    _faceDetector = GoogleMlKit.vision.faceDetector();
    initPlatformState();
    _requestPermissions();
    _loadCameras();
  }

  Future<void> _loadCameras() async {
    try {
      _cameras = await availableCameras();
      _addLog('Cameras loaded: ${_cameras.length} found');
      if (_cameras.isEmpty) {
        _addLog('No cameras available — Check Device Manager > Cameras');
      } else {
        _selectedCamera = _cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
          orElse: () => _cameras.first,
        );
        _addLog('Selected camera: ${_selectedCamera!.name}');
      }
      setState(() {});
    } catch (e) {
      _addLog('Error loading cameras: $e');
    }
  }

  Future<void> _requestPermissions() async {
    final status = await Permission.camera.request();
    _addLog(status.isGranted ? 'Permission granted' : 'Permission denied');
  }

  Future<void> initPlatformState() async {
    try {
      await _controller.initialize();
      final html = await rootBundle.loadString('assets/index.html');
      await _controller.loadStringContent(html);
      if (!mounted) return;
      setState(() {
        _isInitialized = true;
      });
      _addLog('Webview initialized');
      await _controller.executeScript('console.log("Dart connected to JS");');
      _addLog('Test JS script executed');
    } catch (e) {
      _addLog('Webview error: $e');
    }
  }

  Future<void> _initCamera() async {
    if (_selectedCamera == null) {
      _addLog('No camera selected');
      return;
    }

    _addLog('Attempting to initialize camera: ${_selectedCamera!.name}');

    _cameraController = CameraController(_selectedCamera!, ResolutionPreset.low); // Changed from veryLow

    try {
      await _cameraController!.initialize();
      _addLog('Camera controller initialized');

      await Future.delayed(const Duration(milliseconds: 1000));

      _cameraController!.startImageStream(_processCameraImage);
      _addLog('startImageStream called - waiting for first frame');

      // Force periodic check
      streamCheckTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
        _addLog('Stream check ${timer.tick} seconds - no frame yet?');
        if (timer.tick > 10) {
          _addLog('Stream never started - possible driver issue');
          timer.cancel();
        }
      });
    } catch (e) {
      _addLog('Camera init/stream error: $e');
    }
  }

  Future<void> _processCameraImage(CameraImage image) async {
    if (streamCheckTimer != null && streamCheckTimer!.isActive) {
      _addLog('Stream started - canceling check timer');
      streamCheckTimer!.cancel();
    }

    frameCount++;
    if (frameCount % 5 == 0) {
      _addLog('Processing frame $frameCount (width: ${image.width}, height: ${image.height})');
    }

    final WriteBuffer allBytes = WriteBuffer();
    for (Plane plane in image.planes) {
      allBytes.putUint8List(plane.bytes);
    }
    final bytes = allBytes.done().buffer.asUint8List();

    final inputImage = InputImage.fromBytes(
      bytes: bytes,
      metadata: InputImageMetadata(
        size: Size(image.width.toDouble(), image.height.toDouble()),
        rotation: InputImageRotation.rotation0deg,
        format: InputImageFormat.nv21,
        bytesPerRow: image.planes[0].bytesPerRow,
      ),
    );

    try {
      final faces = await _faceDetector!.processImage(inputImage);
      if (frameCount % 5 == 0) {
        _addLog('Faces detected in frame $frameCount: ${faces.length}');
      }

      if (faces.isNotEmpty) {
        final face = faces.first;
        final faceCenterX = face.boundingBox.left + face.boundingBox.width / 2;
        final faceCenterY = face.boundingBox.top + face.boundingBox.height / 2;

        setState(() {
          headX = (faceCenterX / image.width) * 2 - 1;
          headY = (faceCenterY / image.height) * 2 - 1;
        });
        _addLog('Face center: x=$headX, y=$headY');

        try {
          await _controller.executeScript(
            'window.dispatchEvent(new CustomEvent("message", {detail: {type: "headTracking", headX: $headX, headY: $headY}}));'
          );
          _addLog('Sent to JS: headX=$headX, headY=$headY');
        } catch (e) {
          _addLog('JS send error: $e');
        }
      }
    } catch (e) {
      _addLog('Face detection error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: MouseRegion(
        onHover: (event) {
          if (!isHeadMode) {
            setState(() {
              headX = (event.position.dx / size.width) * 2 - 1;
              headY = (event.position.dy / size.height) * 2 - 1;
            });
          }
        },
        child: Stack(
          children: [
            if (_isInitialized) Webview(_controller, permissionRequested: _onPermissionRequested),
            if (!_isInitialized) const Center(child: CircularProgressIndicator()),
            Positioned(
              bottom: 40,
              left: 40,
              child: Text(
                '3D CUBE INTERIOR ACTIVE\nViewer = Front Side\nx: ${headX.toStringAsFixed(2)}   y: ${headY.toStringAsFixed(2)}\n\nMove mouse slowly - look inside the cube!',
                style: const TextStyle(color: Colors.white, fontSize: 20, backgroundColor: Colors.black54),
              ),
            ),
            Positioned(
              top: 40,
              left: 40,
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    isHeadMode = !isHeadMode;
                  });
                  if (isHeadMode) {
                    _initCamera();
                  } else {
                    _cameraController?.dispose();
                  }
                },
                child: Text(isHeadMode ? 'Switch to Mouse Mode' : 'Switch to Head Mode'),
              ),
            ),
            Positioned(
              top: 80,
              left: 40,
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    showPreview = !showPreview;
                  });
                },
                child: Text(showPreview ? 'Hide Preview' : 'Show Camera Preview'),
              ),
            ),
            Positioned(
              top: 120,
              left: 40,
              child: ElevatedButton(
                onPressed: _initCamera,
                child: const Text('Retry Camera'),
              ),
            ),
            Positioned(
              top: 160,
              left: 40,
              child: DropdownButton<CameraDescription>(
                value: _selectedCamera,
                hint: const Text('Select Camera'),
                onChanged: (CameraDescription? value) {
                  setState(() {
                    _selectedCamera = value;
                  });
                  _initCamera();
                },
                items: _cameras.map((CameraDescription camera) {
                  return DropdownMenuItem<CameraDescription>(
                    value: camera,
                    child: Text(camera.name),
                  );
                }).toList(),
              ),
            ),
            if (showPreview && _cameraController != null && _cameraController!.value.isInitialized)
              Positioned(
                bottom: 100,
                right: 20,
                child: SizedBox(
                  width: 200,
                  height: 150,
                  child: CameraPreview(_cameraController!),
                ),
              ),
            Positioned(
              bottom: 100,
              left: 40,
              child: Container(
                width: 400,
                height: 200,
                color: Colors.black87,
                child: ListView.builder(
                  reverse: true,
                  itemCount: _logs.length,
                  itemBuilder: (context, index) {
                    return Text(_logs[_logs.length - 1 - index], style: const TextStyle(color: Colors.white, fontSize: 12));
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<WebviewPermissionDecision> _onPermissionRequested(String url, WebviewPermissionKind kind, bool isUserInitiated) async {
    return WebviewPermissionDecision.allow;
  }

  @override
  void dispose() {
    _controller.dispose();
    _cameraController?.dispose();
    _faceDetector?.close();
    super.dispose();
  }
}