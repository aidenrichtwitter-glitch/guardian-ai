const { app, BrowserWindow, session } = require('electron');
app.commandLine.appendSwitch('no-sandbox');
app.commandLine.appendSwitch('disable-gpu-sandbox');
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('use-gl', 'swiftshader');
app.commandLine.appendSwitch('enable-webgl');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
const path = require('path');
const express = require('express');

const PORT = 3939;
let serverReady = false;

// Start embedded Express server
function startServer() {
  const srv = express();
  srv.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'assets', 'index.html'));
  });
  srv.use('/assets', express.static(path.join(__dirname, 'assets')));
  srv.listen(PORT, '127.0.0.1', () => {
    serverReady = true;
  });
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    title: 'Guardian 3D Desktop',
    backgroundColor: '#1A0033',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Auto-grant camera permission
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(permission === 'media');
  });
  session.defaultSession.setPermissionCheckHandler((webContents, permission) => {
    return permission === 'media';
  });

  win.loadURL(`http://127.0.0.1:${PORT}`);
  win.setMenu(null);
}

app.whenReady().then(() => {
  startServer();

  // Wait until server is up then open window
  const tryOpen = () => {
    if (serverReady) {
      createWindow();
    } else {
      setTimeout(tryOpen, 100);
    }
  };
  tryOpen();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
