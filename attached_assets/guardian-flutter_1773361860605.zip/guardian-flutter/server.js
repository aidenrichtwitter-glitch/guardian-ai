const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 5000;

app.get('/', (req, res) => {
  const htmlPath = path.join(__dirname, 'assets', 'index.html');
  let html = fs.readFileSync(htmlPath, 'utf8');

  html = html.replace(
    "window.addEventListener('message', event => {",
    "window.addEventListener('message', event => {\n    const data = event.data || (event.detail);"
  );

  res.send(html);
});

app.use('/assets', express.static(path.join(__dirname, 'assets')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Guardian 3D running on port ${PORT}`);
});
